package com.project.interfaces;

public interface MainInterface
{

  public void loadMethod();

}
