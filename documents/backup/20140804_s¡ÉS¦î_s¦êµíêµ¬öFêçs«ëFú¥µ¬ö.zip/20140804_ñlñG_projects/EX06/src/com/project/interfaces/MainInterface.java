package com.project.interfaces;

public interface MainInterface
{

  public String sayHello(); 
  public void loadMethod();
  public String[] fileSize(long size);
  
}
