/** Automatically generated file. DO NOT MODIFY */
package irdc.ex06_02;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}