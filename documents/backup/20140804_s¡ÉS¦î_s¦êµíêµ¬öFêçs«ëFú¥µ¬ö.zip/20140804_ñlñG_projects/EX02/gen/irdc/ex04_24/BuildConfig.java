/** Automatically generated file. DO NOT MODIFY */
package irdc.ex04_24;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}